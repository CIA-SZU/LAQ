from dataclasses import dataclass
import torch
from Problem import get_random_problems, augment_x_y_by_8


@dataclass
class Reset_State:
    depot_x_y: torch.Tensor = None          # (batch_size, depot_size, 2)
    pickup_x_y: torch.Tensor = None         # (batch_size, customer_size, 2)
    delivery_x_y: torch.Tensor = None       # (batch_size, customer_size, 2)
    pickup_demand: torch.Tensor = None      # (batch_size, customer_size)
    delivery_demand: torch.Tensor = None    # (batch_size, customer_size)
    depot_size: int = None
    mt_size: int = None                     # 车辆数
    customer_size: int = None               # 请求数（每个请求含取货+送货）
    capacity: int = None
    max_pick: int = None
    


@dataclass
class Step_State:
    batch_idx: torch.Tensor = None
    mt_idx: torch.Tensor = None
    selected_count: int = None
    pick_num = int = None
    load: torch.Tensor = None
    lock: torch.Tensor = None
    current_node: torch.Tensor = None
    finished: torch.Tensor = None
    # shape: (batch_size, mt_size)
    mask: torch.Tensor = None
    # shape: (batch_size, mt_size, node)


class EnvTrain:
    def __init__(self, **env_params):
        self.env_params = env_params
        self.customer_size = self.env_params['customer_size']
        self.mt_size = self.env_params['mt_size']
        self.depot_size = self.env_params['depot_size']
        self.capacity = self.env_params['capacity']
        self.max_pick = self.env_params['max_pick']
        self.demand_min = self.env_params['demand_min']
        self.demand_max = self.env_params['demand_max']
        self.device = torch.device('cuda', self.env_params['cuda_device_num'])

        self.batch_idx = None
        self.mt_idx = None
        # shape: (batch_size, mt_size)
        self.batch_size = None

        self.all_node_x_y = None
        self.all_node_demand = None

        self.selected_count = None
        self.current_node = None
        # shape: (batch_size, mt_size)
        self.selected_node_list = None
        # shape: (batch_size, mt_size, 0~)

        self.departure_depot = None
        self.at_the_depot = None
        self.last_at_the_depot = None
        # shape: (batch_size, mt_size)
        self.visited_flag = None
        self.pick_num = None
        self.lock = None
        self.load = None
        self.finished = None
        self.mask = None

        self.reset_state = Reset_State()
        self.step_state = Step_State()

    def load_problems(self, batch_size, aug_factor=1):

        self.batch_size = batch_size
        # 生成取货送货问题数据
        depot_x_y, pickup_x_y, delivery_x_y, pickup_demand, delivery_demand, _ = get_random_problems(
            batch_size, self.depot_size, self.customer_size, self.capacity, aug_type=None
        )
        depot_x_y = depot_x_y.to(self.device)
        pickup_x_y = pickup_x_y.to(self.device)
        delivery_x_y = delivery_x_y.to(self.device)
        pickup_demand = pickup_demand.to(self.device)
        delivery_demand = delivery_demand.to(self.device)

        self.all_node_x_y = torch.cat([depot_x_y, pickup_x_y, delivery_x_y], dim=1)
        self.all_node_demand = torch.cat([
            torch.zeros_like(pickup_demand[:, :self.depot_size]),
            pickup_demand,
            delivery_demand
        ], dim=1)
        
        # 初始化索引
        self.mt_size = min(self.mt_size, int(self.depot_size+self.customer_size)-1)
        self.batch_idx = torch.arange(self.batch_size)[:, None].expand(self.batch_size, self.mt_size)
        self.mt_idx = torch.arange(self.mt_size)[None, :].expand(self.batch_size, self.mt_size)
        
        self.reset_state.depot_x_y = depot_x_y
        self.reset_state.pickup_x_y = pickup_x_y
        self.reset_state.delivery_x_y = delivery_x_y
        self.reset_state.pickup_demand = pickup_demand
        self.reset_state.delivery_demand = delivery_demand
        self.reset_state.depot_size = self.depot_size
        self.reset_state.customer_size = self.customer_size
        self.reset_state.mt_size = self.mt_size
        self.reset_state.capacity = self.capacity

        self.step_state.batch_idx = self.batch_idx
        self.step_state.mt_idx = self.mt_idx

    def reset(self):
        self.selected_count = 0
        self.current_node = None
        
        self.selected_node_list = torch.zeros((self.batch_size, self.mt_size, 0), dtype=torch.long).to(self.device)
        # shape: (batch_size, mt_size, 0~)
        self.departure_depot = torch.zeros(size=(self.batch_size, self.mt_size), dtype=torch.long).to(self.device)
        # shape: (batch_size, mt_size)
        self.at_the_depot = torch.ones(size=(self.batch_size, self.mt_size), dtype=torch.bool).to(self.device)
        # shape: (batch_size, mt_size)
        self.last_at_the_depot = torch.ones(size=(self.batch_size, self.mt_size), dtype=torch.bool).to(self.device)
        # shape: (batch_size, mt_size)
        self.at_the_pick = torch.zeros(size=(self.batch_size, self.mt_size), dtype=torch.bool).to(self.device)
        self.pick_num = torch.zeros(size=(self.batch_size, self.mt_size)).to(self.device)
        self.load = torch.zeros(size=(self.batch_size, self.mt_size)).to(self.device)
        # shape: (batch_size, mt_size)
        self.visited_flag = torch.zeros((self.batch_size, self.mt_size, self.depot_size + 2*self.customer_size)).to(self.device)
        self.lock = torch.zeros(size=(self.batch_size, self.mt_size, self.depot_size + 2*self.customer_size)).to(self.device)
        self.lock[:, :, self.depot_size+self.customer_size:] = float('-inf')
        self.mask = torch.zeros(size=(self.batch_size, self.mt_size, self.depot_size + 2*self.customer_size)).to(self.device)
        # shape: (batch_size, mt_size, node)
        self.finished = torch.zeros(size=(self.batch_size, self.mt_size), dtype=torch.bool).to(self.device)
        # shape: (batch_size, mt_size)

        reward = None
        done = False
        return self.reset_state, reward, done

    def pre_step(self):
        self.step_state.selected_count = self.selected_count
        self.step_state.current_node = self.current_node
        self.step_state.pick_num = self.pick_num
        self.step_state.load = self.load
        self.step_state.lock = self.lock
        self.step_state.mask = self.mask
        self.step_state.finished = self.finished

        reward = None
        done = False
        return self.step_state, reward, done

    def step(self, selected):

        self.selected_count += 1
        self.current_node = selected
        # shape: (batch_size, mt_size)
        self.selected_node_list = torch.cat((self.selected_node_list, self.current_node[:, :, None]), dim=2)
        # shape: (batch_size, mt_size, 0~)
        self.at_the_depot = (selected < self.depot_size)
        self.departure_depot[self.at_the_depot] = self.current_node[self.at_the_depot]
        self.at_the_pick = (selected < self.depot_size + self.customer_size) * (selected >= self.depot_size)

        demand_list = self.all_node_demand[:, None, :].expand(self.batch_size, self.mt_size, -1)
        # shape: (batch_size, mt_size, node)
        index_to_gather = selected[:, :, None]
        # shape: (batch_size, mt_size, 1)
        selected_demand = demand_list.gather(dim=2, index=index_to_gather).squeeze(dim=2)
        # shape: (batch_size, mt_size)
        self.load += selected_demand
        self.load[self.at_the_depot] = 0  # reset at the depot

        self.pick_num[self.at_the_pick] += 1
        self.pick_num[self.at_the_depot] = 0

        self.visited_flag[self.batch_idx, self.mt_idx, selected] = float('-inf')
        # shape: (batch_size, mt_size, node_size)
        self.visited_flag[:, :, 0:self.depot_size][self.at_the_depot] = 0 
        self.visited_flag[:, :, 0:self.depot_size][self.last_at_the_depot] = float('-inf') 
        self.visited_flag[:, :, 0:self.depot_size][self.last_at_the_depot + ~self.at_the_depot] = float('-inf')
        self.visited_flag[self.batch_idx, self.mt_idx, self.departure_depot] = 0 
        self.visited_flag[self.batch_idx, self.mt_idx, selected] = float('-inf')
        
        self.last_at_the_depot = self.at_the_depot

        unlock = selected.clone()
        unlock[self.at_the_pick] += self.customer_size # 解锁pick对应的delivery
        self.lock[self.batch_idx, self.mt_idx, unlock] = 0 
        self.mask = self.visited_flag.clone() + self.lock.clone()

        # 检查是否有未完成的送货任务（解锁但未访问）
        pending_deliveries = (self.lock[:, :, self.depot_size+self.customer_size:] == 0) & \
                        (self.visited_flag[:, :, self.depot_size+self.customer_size:] == 0)
        has_pending = pending_deliveries.any(dim=2)  # (batch_size, mt_size)

        # 如果有未完成的送货任务，屏蔽所有仓库节点
        self.mask[:, :, :self.depot_size] = torch.where(
            has_pending.unsqueeze(2).expand(-1, -1, self.depot_size),
            torch.tensor(float('-inf'), device=self.device),
            self.mask[:, :, :self.depot_size]
        )

        # self.mask = self.visited_flag.clone()
        round_error_epsilon = 0.00001
        demand_too_large = 1 - self.load[:, :, None] + round_error_epsilon < demand_list
        # shape: (batch_size, mt_size, node_size)
        self.mask[demand_too_large] = float('-inf')
        # shape: (batch_size, mt_size)

        pick_too_large = self.pick_num + round_error_epsilon > self.max_pick
        self.mask[:, :, self.depot_size: self.depot_size+self.customer_size] = torch.where(
            pick_too_large.unsqueeze(2).expand(-1, -1, self.customer_size),
            torch.tensor(float('-inf'), device=self.device),
            self.mask[:, :, self.depot_size: self.depot_size+self.customer_size]
        )

        new_finished = (self.visited_flag[:, :, self.depot_size:] == float('-inf')).all(dim=2)
        # shape: (batch_size, mt_size)
        self.finished = self.finished + new_finished
        # self.mask[self.batch_idx, self.mt_idx, self.departure_depot][self.finished] = 0  # do not mask depot for finished episode.
        self.mask[:,:,0:self.depot_size][self.finished] = 0 
        self.step_state.selected_count = self.selected_count
        self.step_state.pick_num = self.pick_num
        self.step_state.load = self.load
        self.step_state.current_node = self.current_node
        self.step_state.mask = self.mask
        self.step_state.finished = self.finished

        done = self.finished.all()
        if done:
            reward = -self.get_travel_distance()
            self.step_state.result_node_list = self.selected_node_list
        else:
            reward = None

        return self.step_state, reward, done
    
    def get_current_assign(self):
        return self.assign.gather(2, self.count_depot)

    def get_travel_distance(self):
        # 提取部分路径中节点的坐标
        index_to_gather = self.selected_node_list[:, :, :, None].expand(-1, -1, -1, 2)
        all_x_y = self.all_node_x_y[:, None, :, :].expand(-1, self.mt_size, -1, -1)
        seq_ordered = all_x_y.gather(dim=2, index=index_to_gather)

        # 判断部分路径中的节点是否为仓库节点
        depot_ordered = self.selected_node_list < self.depot_size
        depot_rolled = depot_ordered.roll(dims=2, shifts=-1)
        depot_final = depot_ordered * depot_rolled

        # 计算相邻节点之间的距离
        seq_rolled = seq_ordered.roll(dims=2, shifts=-1)
        segment_lengths = ((seq_ordered - seq_rolled) ** 2).sum(3).sqrt()

        # 如果相邻节点都是仓库节点，将距离设置为 0
        segment_lengths[depot_final] = 0

        # 忽略最后一个节点的距离（因为没有下一个节点）
        segment_lengths = segment_lengths[:, :, :-1]

        # 计算每辆车的总行驶距离
        travel_distances = segment_lengths.sum(2)
        return travel_distances
    